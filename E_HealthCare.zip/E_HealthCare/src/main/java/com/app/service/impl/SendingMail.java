package com.app.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.entity.modal.Admin;
import com.app.repository.AdminRepository;
import com.app.repository.DoctorRepository;
import com.app.repository.PatientRepository;
import com.app.service.intf.AdminServiceIntf;

@Configuration
public class SendingMail implements Runnable {

	private EmailSenderService emailSenderService;
	
	public SendingMail(EmailSenderService emailSenderService) {

		this.emailSenderService = emailSenderService;
	}
	public String email;
	public Long token;
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		emailSenderService.sendEmailTokenToResetPassword(email, token); 
	}



}
